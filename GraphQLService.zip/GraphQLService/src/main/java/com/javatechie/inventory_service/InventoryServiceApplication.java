package com.javatechie.inventory_service;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@SpringBootApplication
public class InventoryServiceApplication {

    @Autowired
	private CustodianRepository custodianRepository;

	@PostConstruct
	public void initDB(){
		List<Custodian> custodians =
				Stream.of(new Custodian("akkhil"),new Custodian("arihaan")).collect(Collectors.toList());

		custodianRepository.saveAll(custodians);
	}

	public static void main(String[] args) {
		SpringApplication.run(InventoryServiceApplication.class, args);
	}

}
