package com.javatechie.inventory_service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/*@RestController
@RequestMapping("/custodians")*/
@Controller
public class CustodianController {

    @Autowired
    private CustodianService custodianService;

   // @GetMapping
    @QueryMapping
    public List<Custodian> getCustodians(){
        return  custodianService.getCustodians();
    }

    @QueryMapping
    public List<Custodian> getCustodiansByRole(@Argument String role){
        return  custodianService.getCustodiansByRole(role);
    }

}
