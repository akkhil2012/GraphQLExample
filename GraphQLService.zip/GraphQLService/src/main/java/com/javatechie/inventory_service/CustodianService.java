package com.javatechie.inventory_service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustodianService {

    @Autowired
    CustodianRepository custodianRepository;

    public List<Custodian> getCustodians(){
        return custodianRepository.findAll();
    }

    public List<Custodian> getCustodiansByRole(String role){
        return custodianRepository.findByRole(role);
    }
}
