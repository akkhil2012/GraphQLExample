package com.launchPad.LaunchPadExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaunchPadExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
