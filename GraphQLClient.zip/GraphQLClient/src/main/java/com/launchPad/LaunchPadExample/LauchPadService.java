package com.launchPad.LaunchPadExample;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LauchPadService {

    @Autowired
    InventoryClient inventoryClient;

    public List<Item> viewCustodians() {
        return inventoryClient.viewCustodians();
    }

    public List<Item> viewCustodiansByRole(String role) {
        return inventoryClient.viewCustodiansByRole(role);
    }

    public List<Item> viewCustodiansByRoleAndId(String role) {
        return inventoryClient.viewCustodiansByRoleAndId(role);
    }
}
