package com.launchPad.LaunchPadExample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.client.HttpGraphQlClient;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;

@Component
public class InventoryClient {

    @Autowired
    private HttpGraphQlClient graphQlClient;

    public List<Item> viewCustodians(){
        String graphQLQuery = "query GetCustodians {\n" +
                "    getCustodians {\n" +
                "        id\n" +
                "        role\n" +
                "    }\n" +
                "}";

        List<Item> res = graphQlClient.document(graphQLQuery)
                .retrieve("getCustodians")
                .toEntityList(Item.class)
                .block();
        res.stream().forEach(val -> System.out.println(" >> " +val.getRole()));

        return res;
    }


    public List<Item> viewCustodiansByRole(String role) {

        String graphQLQuery = String.format("query GetCustodiansByRole {\n" +
                "    getCustodiansByRole(role: \"%s\") {\n" +
                "        id\n" +
                "        role\n" +
                "    }\n" +
                "}", role);

        List<Item> byRole =  graphQlClient.document(graphQLQuery)
                .retrieve("getCustodiansByRole")
                .toEntityList(Item.class).block();
        byRole.stream().forEach(val -> System.out.println(" "+val.getRole()));
        return  byRole;
    }

    public List<Item> viewCustodiansByRoleAndId(String role) {

        String graphQLQuery = String.format("query GetCustodiansByRole {\n" +
                "    getCustodiansByRole(role: \"%s\") {\n" +
                "        role\n" +
                "    }\n" +
                "}\n", role);

        List<Item> byRole =  graphQlClient.document(graphQLQuery)
                .retrieve("getCustodiansByRole")
                .toEntityList(Item.class).block();
        byRole.stream().forEach(val -> System.out.println(" "+val.getRole()));
        return  byRole;
    }
}
