package com.launchPad.LaunchPadExample;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/custodian")
public class LaunchPadController {

    @Autowired
    LauchPadService lauchPadService;

    @GetMapping("/search")
    public List<Item> viewCustodians() {
        return lauchPadService.viewCustodians();
    }

    @GetMapping("/roles")
    public List<Item> searchByRole(@RequestParam String role) {
        return lauchPadService.viewCustodiansByRole(role);
    }

    @GetMapping("/rolesAndIds")
    public List<Item> searchByrolesAndIds(@RequestParam String role) {
        return lauchPadService.viewCustodiansByRoleAndId(role);
    }

}
