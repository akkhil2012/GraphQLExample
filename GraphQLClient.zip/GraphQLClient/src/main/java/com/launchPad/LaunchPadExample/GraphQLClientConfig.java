package com.launchPad.LaunchPadExample;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.graphql.client.HttpGraphQlClient;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClientConfig;

@Configuration
public class GraphQLClientConfig {

    //Create Bean of GraphQLClient
    @Bean
    public HttpGraphQlClient graphQlClient(){

        WebClient webClient = WebClient.builder().
                baseUrl("http://localhost:9191/graphql")
                .build();
        return HttpGraphQlClient.builder(webClient).build();
    }
}
